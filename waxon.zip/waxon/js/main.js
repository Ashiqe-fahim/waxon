
$(function() {
    // bannerslider
    $('.banner-slide-item').slick({
        slidesToShow: 1,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 2000,
        arrows:false,
        speed:1500,
      });

// venobox video
$('.venobox').venobox(); 

// counterup
$('.counter').counterUp({
  delay: 10,
  time: 3000
});


// service slider
$('.service-slider').slick({
  slidesToShow: 4,
  slidesToScroll: 1,
  autoplay: true,
  autoplaySpeed: 2000,
  arrows:false,
  speed:2000,
  centerMode:true,
  centerPadding: false,
});




// blogslider
$('.blog-slider').slick({
  slidesToShow: 3,
  slidesToScroll: 1,
  autoplay: true,
  autoplaySpeed: 2000,
  arrows:false,
  speed:2000,
  centerMode:true,
  centerPadding: false,
});

// client logo

$('.client-logo').slick({
  slidesToShow: 4,
  slidesToScroll: 1,
  autoplay: true,
  autoplaySpeed: 2000,
  arrows:false,
  speed:2000,
  centerMode:true,
  centerPadding: false,
});






});



